const socket = io();

const messages = document.getElementById("messages");
const messageInput = document.getElementById("message");
const sendBtn = document.getElementById("send");
const who = document.getElementById("who");
const logoutBtn = document.getElementById("logout");

sendBtn.addEventListener("click", sendMessage);
messageInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendMessage();
});

logoutBtn.addEventListener("click", async () => {
    await fetch("/api/logout", { method: "POST" });
    location.href = "/chat/login";
});

async function loadMe() {
    const r = await fetch("/api/me");
    const j = await r.json();
    if (!j.user) location.href = "/chat/login";
    who.textContent = j.user;
}
loadMe();

function addMsg(data) {
    const div = document.createElement("div");
    div.className = "chat-message";
    const time = data.t ? new Date(data.t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " " : "";
    div.textContent = `${time}${data.user}: ${data.text}`;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

function sendMessage() {
    const text = messageInput.value.trim();
    if (!text) return;
    socket.emit("chatMessage", { text });
    messageInput.value = "";
}

socket.on("chatMessage", (data) => addMsg(data));
socket.on("chat:history", (history) => {
    messages.innerHTML = "";
    (history || []).forEach(addMsg);
    messages.scrollTop = messages.scrollHeight;
});
