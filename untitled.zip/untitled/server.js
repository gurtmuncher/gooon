const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const session = require("express-session");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 3000;


app.use(express.json());


const sessionMiddleware = session({
    secret: "change-this-to-a-long-random-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true }
});

app.use(sessionMiddleware);


io.engine.use(sessionMiddleware);


const DATA_FILE = path.join(__dirname, "count.json");
let count = 0;

try {
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    const parsed = JSON.parse(raw);
    if (typeof parsed.count === "number") count = parsed.count;
} catch {
    count = 0;
}

function saveCount() {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ count }), "utf8");
}


const CHAT_FILE = path.join(__dirname, "chatlog.json");
let chatlog = [];

try {
    const raw = fs.readFileSync(CHAT_FILE, "utf8");
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) chatlog = parsed;
} catch {
    chatlog = [];
}

function saveChat() {
    fs.writeFileSync(CHAT_FILE, JSON.stringify(chatlog.slice(-200), null, 2), "utf8");
}


const USERS_FILE = path.join(__dirname, "users.json");
let users = {};

try {
    const raw = fs.readFileSync(USERS_FILE, "utf8");
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object") users = parsed;
} catch {
    users = {};
}

function saveUsers() {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), "utf8");
}

function hashPassword(password, salt) {

    const hash = crypto.pbkdf2Sync(password, salt, 120000, 32, "sha256").toString("hex");
    return hash;
}

function requireLogin(req, res, next) {
    if (req.session?.user) return next();
    return res.redirect("/chat/login");
}


app.use(express.static(path.join(__dirname, "public")));


app.get("/api/count", (req, res) => res.json({ count }));

app.get("/chat/login", (req, res) => {
    res.sendFile(path.join(__dirname, "public/chat/login.html"));
});

app.get("/api/me", (req, res) => {
    res.json({ user: req.session?.user || null });
});

app.post("/api/register", (req, res) => {
    const username = String(req.body?.username || "").trim();
    const password = String(req.body?.password || "");

    if (username.length < 3 || username.length > 24) {
        return res.status(400).json({ ok: false, error: "Username must be 3-24 chars." });
    }
    if (password.length < 6 || password.length > 72) {
        return res.status(400).json({ ok: false, error: "Password must be 6-72 chars." });
    }

    const key = username.toLowerCase();
    if (users[key]) {
        return res.status(400).json({ ok: false, error: "Username already taken." });
    }

    const salt = crypto.randomBytes(16).toString("hex");
    const hash = hashPassword(password, salt);

    users[key] = { username, salt, hash };
    saveUsers();


    req.session.user = username;
    return res.json({ ok: true, user: username });
});

app.post("/api/login", (req, res) => {
    const username = String(req.body?.username || "").trim();
    const password = String(req.body?.password || "");

    const key = username.toLowerCase();
    const record = users[key];
    if (!record) return res.status(400).json({ ok: false, error: "Invalid login." });

    const attempt = hashPassword(password, record.salt);
    if (attempt !== record.hash) return res.status(400).json({ ok: false, error: "Invalid login." });

    req.session.user = record.username;
    return res.json({ ok: true, user: record.username });
});

app.post("/api/logout", (req, res) => {
    req.session.destroy(() => res.json({ ok: true }));
});


app.get("/chat", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "public/chat/index.html"));
});


io.on("connection", (socket) => {
    const sess = socket.request.session;
    const user = sess?.user || null;


    socket.data.user = user;


    socket.emit("count:update", count);


    socket.emit("chat:history", chatlog);

    socket.on("count:increment", () => {
        count++;
        saveCount();
        io.emit("count:update", count);
    });

    socket.on("chatMessage", (data) => {
        if (!socket.data.user) return;

        const msg = {
            user: socket.data.user,
            text: String(data?.text || "").slice(0, 300),
            t: Date.now()
        };

        chatlog.push(msg);
        if (chatlog.length > 200) chatlog.shift();
        saveChat();

        io.emit("chatMessage", msg);
    });
});


server.listen(PORT, () => {
    console.log(`Server running:
- Login: http://localhost:${PORT}/chat/login
- Chat:  http://localhost:${PORT}/chat`);
});
